const board = document.getElementById('board');
const message = document.getElementById('message');
const restartBtn = document.getElementById('restartBtn');
const background = document.querySelector('.background');

let currentPlayer = 'X';
let gameActive = true;
let boardState = ['', '', '', '', '', '', '', '', ''];

const WINNING_COMBINATIONS = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
    [0, 4, 8], [2, 4, 6] // Diagonals
];

function playerMove(cellIndex) {
    if (gameActive && boardState[cellIndex] === '') {
        boardState[cellIndex] = currentPlayer;
        document.getElementsByClassName('cell')[cellIndex].innerText = currentPlayer;
        if (checkWin()) {
            showResult(`${currentPlayer} wins!`);
            gameActive = false;
        } else if (isBoardFull()) {
            showResult("It's a draw!");
            gameActive = false;
        } else {
            currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
            message.innerText = `Player ${currentPlayer}'s turn`;
        }
    }
}

function checkWin() {
    return WINNING_COMBINATIONS.some(combination => {
        return combination.every(index => {
            return boardState[index] === currentPlayer;
        });
    });
}

function isBoardFull() {
    return boardState.every(cell => {
        return cell !== '';
    });
}

function restart() {
    currentPlayer = 'X';
    gameActive = true;
    boardState = ['', '', '', '', '', '', '', '', ''];
    message.innerText = `Player ${currentPlayer}'s turn`;
    document.querySelectorAll('.cell').forEach(cell => cell.innerText = '');
    hideResult();
}

function showResult(text) {
    const resultScreen = document.createElement('div');
    resultScreen.classList.add('result-screen');
    resultScreen.innerHTML = `
        <h2>${text}</h2>
        <button onclick="restart()">New Game</button>
    `;
    background.appendChild(resultScreen);
    background.style.display = 'flex';
}

function hideResult() {
    background.style.display = 'none';
    background.innerHTML = '';
}